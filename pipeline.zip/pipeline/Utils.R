
get_expression_vector <- function(name, type = "normalized", SeuratObject){
  #print(rownames(SeuratObject@assays$RNA@data)[which(unlist(lapply(strsplit(rownames(SeuratObject@assays$RNA@data), ":"), "[[", 2)) == name)])
  if(type == "normalized")
    x <-  SeuratObject@assays$RNA@data[which(unlist(lapply(strsplit(rownames(SeuratObject@assays$RNA@data), ":"), "[[", 2)) == name),]
  else if(type == "counts")
    x <- SeuratObject@assays$RNA@counts[which(unlist(lapply(strsplit(rownames(SeuratObject@assays$RNA@data), ":"), "[[", 2)) == name),]
  return(x)
}


## get target gene
get_target_gene <- function(guides_call){
  guides_call <- unlist(lapply(strsplit(guides_call, ":"), "[[", 1))
  rtn <- unlist(lapply(guides_call, FUN = function(x){
    if ( x == "unassigned"){
      return("unassigned")
    } else{
      #print(x)
      paste(rev(rev(unlist(strsplit(x, split = "_|-")))[-1]), collapse = "_")
    }
  }), "[[", 1)
  return(rtn)
}

#claudia <- cor(matrix(rnorm(100),10,10))
#my_heatmap(claudia, min_c = -1)

my_heatmap <- function(data, divergent_colors = TRUE, midpoint =0,
                       ncols = 100, x_label="", y_label="", min_c = NULL, max_c = NULL,...){
  if(divergent_colors){
    if(is.null(min_c))
      min_dat <- min(min(data, na.rm = TRUE), midpoint)
    else
      min_dat <- min_c
    if(is.null(max_c))
      max_dat <- max(max(data, na.rm = TRUE), midpoint)
    else
      max_dat <- max_c
    seq_breaks <- c(seq(min_dat, midpoint, (midpoint-min_dat)/ncols * 2), seq(midpoint, max_dat, (max_dat-midpoint)/ncols * 2)[-1])
    # setHook("grid.newpage", function() pushViewport(viewport(x=1,y=1,width=0.9, height=0.9, name="vp", just=c("right","top"))), action="prepend")
    pheatmap::pheatmap(data, color = rev(colorRampPalette((RColorBrewer::brewer.pal(n = 7, name ="RdBu")))(ncols)), breaks = seq_breaks, ...)
  } else {
    # setHook("grid.newpage", function() pushViewport(viewport(x=1,y=1,width=0.9, height=0.9, name="vp", just=c("right","top"))), action="prepend")
    pheatmap::pheatmap(data, color = colorRampPalette((RColorBrewer::brewer.pal(n = 7, name ="Blues")))(ncols), ...)
  }
  # grid.text(x_label, y=-0.07, gp=gpar(fontsize=16))
  # grid.text(y_label, x=-0.07, rot=90, gp=gpar(fontsize=16))
}




## ---- PlotDownstreamEffects

#double heatmap
double_heatmap <- function(cor_mat1, cor_mat2,
                           title_arg = "", ...){
  #mat1 should be the LFCs
  
  # take ordering from mat1 and tranfer to mat2 and set lower triangle to zero
  order1 <- hclust(dist(cor_mat1))$order
  names_order1 <- row.names(cor_mat1)[order1]
  corCombi2 <- cor_mat2[order1,order1] 
  corCombi2[lower.tri(corCombi2, diag = F)] <- 0
  
  # apply ordering to correlatin matrix of mat1 and set upper triangle to zero
  corCombi1<-cor_mat1[order1,order1] 
  corCombi1[upper.tri(corCombi1, diag = F)] <- 0
  
  corCombi <- corCombi1 + corCombi2
  diag(corCombi) <- 1
  
  #pdf(paste0(HomeFolder, "scratch/22-06-01_plots.pdf"), width = 7, height = 6.5)
  #pheatmap(lfc_cor_mat)
  #pheatmap(coexpression_correlation)
  p <- my_heatmap(corCombi, cluster_rows = FALSE, cluster_cols =FALSE, 
                ...)
  #dev.off()
  return(p)
}



## double heatmap with ipscs vs K562
compare_cell_types <- function(genes_of_interest, target_target_cor_anno,
                               cell_type_of_interest = 'K562_gwps_cor', ...){
  
  df4heatmap_iPSCs <- target_target_cor_anno %>%
    dplyr::select(c('gene_1', 'gene_2', 'cor_all')) %>%
    dplyr::filter(gene_1 %in% genes_of_interest & gene_2 %in% genes_of_interest) %>%
    reshape2::dcast(gene_1 ~ gene_2, value.var = 'cor_all') %>%
    column_to_rownames('gene_1') %>%
    as.matrix()
  df4heatmap_K562 <- target_target_cor_anno %>%
    dplyr::select(c('gene_1', 'gene_2', cell_type_of_interest)) %>%
    dplyr::filter(gene_1 %in% genes_of_interest & gene_2 %in% genes_of_interest) %>%
    reshape2::dcast(gene_1 ~ gene_2, value.var = cell_type_of_interest) %>%
    column_to_rownames('gene_1') %>%
    as.matrix()
  
  
  p <- double_heatmap(df4heatmap_iPSCs, df4heatmap_K562, 
                      ...)
  p <- ggarrange(p[[4]])
  return(p)
}



## ---- LM functionss

run_lm <- function(perturbed_normalized_expression, perturbed_cell_metadata,
                   #perturbed_cells,
                   control_fit){
  
  t0 <- Sys.time()
  # compute lfc
  predicted_perturbed_means <- perturbed_cell_metadata %*% control_fit$coefficients 
  #old_predicted_perturbed_means <- predict(old_control_lm, perturbed_cell_metadata)
  lfc <- mean(perturbed_normalized_expression - predicted_perturbed_means)
  v <- var(perturbed_normalized_expression - predicted_perturbed_means)
  
  # compute pvalue 
  control_expression_variance <- control_fit$residuals_var
  #control_expression_variance <- var(control_fit$residuals)
  z_score <- lfc/sqrt(control_expression_variance)
  pval <- 2 * pnorm(-abs(z_score), mean = 0, sd = 1 / sqrt(length(predicted_perturbed_means)))
  
  #print(Sys.time() - t0)
  return(list(lfc = lfc, pval = pval, v = v,
              res = perturbed_normalized_expression - predicted_perturbed_means))
  
}

#in_matrix <- perturbed_cell_metadata
#coefficients <- control_lm$coefficients
reformat_metadata_matrix <- function(in_matrix, coefficients){
  rtn <- matrix(0, nrow = dim(in_matrix)[1], ncol = length(coefficients))
  rtn[,1] <- 1
  row.names(rtn) <- row.names(in_matrix); colnames(rtn) <- names(coefficients)
  for (j in 1:dim(in_matrix)[2]){
    if (class(in_matrix[,j]) == "character"){
      for (i in 1:dim(in_matrix)[1]){
        name_in_coef_vector <- paste0(colnames(in_matrix)[j], in_matrix[i,j])
        if (name_in_coef_vector %in% names(coefficients)){
          rtn[row.names(in_matrix)[i], name_in_coef_vector] <- 1
        }
      }
    } else {
      name_in_coef_vector <- colnames(in_matrix)[j]
      rtn[,name_in_coef_vector] <- in_matrix[,j]
    }
  }
  return(rtn)
}


#compute correlations

cor.test.p <- function(x){
  FUN <- function(x, y) cor.test(x, y)[["p.value"]]
  z <- outer(
    colnames(x), 
    colnames(x), 
    Vectorize(function(i,j) FUN(x[,i], x[,j]))
  )
  dimnames(z) <- list(colnames(x), colnames(x))
  z
}


calc_cor <- function(df1, df2,
                     is_1_complex = F,
                     is_2_complex = F,
                     sig_pval_thresh = 0.1, 
                     plot_title="", xlab1 = df1$target[1], ylab1 = df2$target[1],
                     anno  = F, by_pval = T){
  
  all_downstream_genes <- df1$downstream_gene_name
  
  if (by_pval == T){
    deg1 <- df1 %>% dplyr::filter(pval_adj < sig_pval_thresh) %>% .$downstream_gene_name
    deg2 <- df2 %>% dplyr::filter(pval_adj < sig_pval_thresh) %>% .$downstream_gene_name
  } else {
    deg1 <- df1 %>% dplyr::filter(abs(lfc) > sig_abs_lfc_thresh) %>% .$downstream_gene_name
    deg2 <- df2 %>% dplyr::filter(abs(lfc) > sig_abs_lfc_thresh) %>% .$downstream_gene_name
  }
  all_deg <- unique(c(deg1, deg2))
  common_deg <- intersect(deg1, deg2)
  all_deg_excl_target <- all_deg[which(!(all_deg %in% c(df1$target[1], df2$target[1])))]
  common_deg_excl_target <- common_deg[which(!(common_deg %in% c(df1$target[1], df2$target[1])))]
  
  rtn <- list()
  rtn$df <- data.frame(
    gene_1 = ifelse(is_1_complex, df1$genes_in_complex[1], df1$target[1]),
    n_cells_1 = df1$n_perturbed[1],
    n_deg_1 = length(deg1),
    mean_abs_deg_1 = mean(abs(df1$lfc)),
    gene_2 = ifelse(is_2_complex, df2$genes_in_complex[1], df2$target[1]),
    n_cells_2 = df2$n_perturbed[1],
    n_deg_2 = length(deg2),
    mean_abs_deg_2 = mean(abs(df2$lfc)),
    total_deg = length(all_deg),
    common_deg = length(common_deg),
    cor_all = cor(df1$lfc[match(all_downstream_genes, df1$downstream_gene_name)],
                  df2$lfc[match(all_downstream_genes, df2$downstream_gene_name)]),
    cor_all_pval = tryCatch(
      cor.test(df1$lfc[match(all_downstream_genes, df1$downstream_gene_name)],
               df2$lfc[match(all_downstream_genes, df2$downstream_gene_name)], method = "pearson")$p.value,
      error = function(e){return(NA)}),
    same_sign_all = length(which(sign(df1$lfc[match(all_downstream_genes, df1$downstream_gene_name)]) == sign(df2$lfc[match(all_downstream_genes, df1$downstream_gene_name)]))),
    cor_all_deg = cor(df1$lfc[match(all_deg, df1$downstream_gene_name)],
                      df2$lfc[match(all_deg, df2$downstream_gene_name)]),
    cor_all_deg_pval = tryCatch(
      cor.test(df1$lfc[match(all_deg, df1$downstream_gene_name)],
               df2$lfc[match(all_deg, df2$downstream_gene_name)], method = "pearson")$p.value,
      error = function(e){return(NA)}),
    same_sign_all_deg = length(which(sign(df1$lfc[match(all_deg, df1$downstream_gene_name)]) == sign(df2$lfc[match(all_deg, df2$downstream_gene_name)]))),
    cor_all_deg_excl_target = cor(df1$lfc[match(all_deg_excl_target, df1$downstream_gene_name)],
                                  df2$lfc[match(all_deg_excl_target, df2$downstream_gene_name)]),
    cor_all_deg_excl_target_pval = tryCatch(
      cor.test(df1$lfc[match(all_deg_excl_target, df1$downstream_gene_name)],
               df2$lfc[match(all_deg_excl_target, df2$downstream_gene_name)], method = "pearson")$p.value,
      error = function(e){return(NA)}),
    cor_common_deg = cor(df1$lfc[match(common_deg, df1$downstream_gene_name)],
                         df2$lfc[match(common_deg, df2$downstream_gene_name)]),
    cor_common_deg_pval = tryCatch(
      cor.test(df1$lfc[match(common_deg, df1$downstream_gene_name)],
               df2$lfc[match(common_deg, df2$downstream_gene_name)], method = 'pearson')$p.value,
      error = function(e){return(NA)}),
    cor_common_deg_excl_target = cor(df1$lfc[match(common_deg_excl_target, df1$downstream_gene_name)],
                                     df2$lfc[match(common_deg_excl_target, df2$downstream_gene_name)]),
    cor_common_deg_excl_target_pval = tryCatch(
      cor.test(df1$lfc[match(common_deg_excl_target, df1$downstream_gene_name)],
               df2$lfc[match(common_deg_excl_target, df2$downstream_gene_name)], method = 'pearson')$p.value,
      error = function(e){return(NA)}),
    same_sign_common_deg = length(which(sign(df1$lfc[match(common_deg, df1$downstream_gene_name)]) == sign(df2$lfc[match(common_deg, df2$downstream_gene_name)])))
  ) %>%
    mutate(
      to_match = ifelse(is_1_complex & is_2_complex, paste(sort(gene_1, gene_2), collapse = ":"), "")
    )
  
  df4plot <- data.frame(
    downstream_gene = all_downstream_genes,
    is_deg = factor(all_downstream_genes %in% all_deg),
    e1 = df1$lfc[match(all_downstream_genes, df1$downstream_gene_name)],
    e2 = df2$lfc[match(all_downstream_genes, df2$downstream_gene_name)]
  )
  if (anno == F){
    rtn$p <- ggplot(df4plot, aes(x = e1, y = e2, col = is_deg)) + 
      scale_color_manual(values = c("TRUE" = "red", 'FALSE' = "gray")) + 
      xlab(xlab1) + ylab(ylab1) + ggtitle(plot_title) + 
      geom_point(alpha = 0.4) + theme_bw() + theme(legend.position = 'none')
    
  } else {
    rtn$p <- ggplot(df4plot, aes(x = e1, y = e2, col = is_deg)) + 
      scale_color_manual(values = c("TRUE" = "red", 'FALSE' = "gray")) + 
      xlab(xlab1) + ylab(ylab1) + ggtitle(plot_title) + 
      annotate("text",x=min(df4plot$e1)*0.8,y=max(df4plot$e2)*0.8,label=paste0("r = ", round(rtn$df$cor_all, 4), ",\np = ", round(rtn$df$cor_all_pval, 4))) + 
      geom_point(alpha = 0.4) + theme_bw() + theme(legend.position = 'none')
    
  }
  
  return(rtn)
  
}



## pica scatters

get_control_expression <- function(ExperimentName = "Pica",
                                   OutFolder = paste0("/lustre/scratch123/hgi/projects/crispri_scrnaseq/outs/", ExperimentName, '/'),
                                   date = NULL){
  
  if (is.null(date)){
    most_recent <- sort(gsub(
      list.files(file.path(OutFolder, "6f_calc_lfcs_transcriptome_wide_by_gene_per_line"), recursive = T, pattern = paste0("_", NonTargetGeneName, "_knockdowns_residuals")),
      pattern = paste0(".*by_gene[/]|_", NonTargetGeneName, ".*"),
      replacement = ""), decreasing = T)[1]
    control_expression_fnms <- list.files(file.path(OutFolder, "6f_calc_lfcs_transcriptome_wide_by_gene_per_line"), recursive = T, pattern = paste0(most_recent, "_", NonTargetGeneName, "_knockdowns_residuals"))
  } else {
    control_expression_fnms <- list.files(file.path(OutFolder, "6f_calc_lfcs_transcriptome_wide_by_gene_per_line"), recursive = T, pattern = paste0(date, "_", NonTargetGeneName, "_knockdowns_residuals"))
  }
  control_expression <- lapply(control_expression_fnms, FUN = function(gene_count_fnm){
    rtn <- as.data.frame(fread(file.path(OutFolder, "6f_calc_lfcs_transcriptome_wide_by_gene_per_line", gene_count_fnm)))
    cnms <- c("cell_line", "donor", colnames(rtn))
    rtn <- data.frame(
      cell_line = unlist(lapply(strsplit(gene_count_fnm, "/"), "[[", 1)),
      donor = unlist(lapply(strsplit(gene_count_fnm, "_"), "[[", 1)),
      rtn
    )
    colnames(rtn) <- cnms
    return(rtn)
  }) %>% bind_rows() %>% as.data.frame()
  return(control_expression)
}
get_knockdown_expression <- function(target_gene,
                                     OutFolder = '/lustre/scratch123/hgi/projects/crispri_scrnaseq/outs/Pica/',
                                     date = NULL){
  
  if (is.null(date)){
    most_recent <- sort(gsub(
      list.files(file.path(OutFolder, "6f_calc_lfcs_transcriptome_wide_by_gene_per_line"), recursive = T, pattern = paste0("_", target_gene, "_knockdowns_residuals")),
      pattern = paste0(".*by_target_by_line[/]|_", target_gene, ".*"),
      replacement = ""), decreasing = T)[1]
   # print(most_recent)
    knockdown_expression_fnms <- list.files(file.path(OutFolder, "6f_calc_lfcs_transcriptome_wide_by_gene_per_line"), recursive = T, pattern = paste0(most_recent, "_", target_gene, "_knockdowns_residuals"))
  } else {
    knockdown_expression_fnms <- list.files(file.path(OutFolder, "6f_calc_lfcs_transcriptome_wide_by_gene_per_line"), recursive = T, pattern = paste0(date, "_", target_gene, "_knockdowns_residuals"))
  }
  knockdown_expression <- lapply(knockdown_expression_fnms, FUN = function(gene_count_fnm){
    rtn <- as.data.frame(fread(file.path(OutFolder, "6f_calc_lfcs_transcriptome_wide_by_gene_per_line", gene_count_fnm)))
    cnms <- c("target", "cell_line", "donor", colnames(rtn))
    rtn <- data.frame(
      target = target_gene,
      cell_line = unlist(lapply(strsplit(gene_count_fnm, "/"), "[[", 1)),
      donor = unlist(lapply(strsplit(gene_count_fnm, "_"), "[[", 1)),
      rtn
    )
    colnames(rtn) <- cnms
    return(rtn)
  }) %>% bind_rows() %>% as.data.frame()
  return(knockdown_expression)
}




get_df4lmm <- function(kd_expr = NULL, 
                       downstream_gene_name, target_gene = kd_expr$target[1],
                       lines2include = LineMetadata$name,
                       include_line_quality = T,
                       include_sex = T, line_metadata = LineMetadata,
                       keep_singleton_lines = F,
                       ExperimentName = "Pica", 
                       date = NULL,
                       OutFolder = paste0(ProjectFolder, "/outs/", ExperimentName),
                       min_cells_per_gene_per_donor = 10,
                       include_guide = T){
  
  
  if (is.null(kd_expr)){
    kd_expr <- get_knockdown_expression(target_gene = target_gene, date = date)
  }
  downstream_gene <- grep(colnames(kd_expr), pattern = paste0(":", downstream_gene_name, ":"), value = T)
  if (is.null(date)){
    date <- sort(grep(list.files(file.path(OutFolder, "/6a_run_control_lm/")), pattern = 'bsub_outs', invert = T, value = T), decreasing = T)[1]
    fnm <- sort(list.files(file.path(OutFolder, "/6a_run_control_lm/", date),
                                     pattern = paste0("gene-", gsub(downstream_gene, pattern = ":", replacement = "-"), ".RDS"), full.names = T), 
                decreasing = T)[1]
    control_lm <- readRDS(fnm)
  } else {
    control_lm <- readRDS(paste0(OutFolder, "/6a_run_control_lm/", date, "/gene-", gsub(downstream_gene, pattern = ":", replacement = "-"), ".RDS"))
  }
  wt_expression_line_coefficients <- control_lm$coefficients[grep(names(control_lm$coefficients), pattern = "cell_line")]
  names(wt_expression_line_coefficients) <- gsub(names(wt_expression_line_coefficients), pattern= "cell_line", replacement = "")
  #print('a')
  
  if (include_guide == T){
    df4lmm <- dplyr::select(kd_expr, all_of(c("target", "id", "cell_line", "donor", 'guide', downstream_gene))) %>%
      dplyr::mutate(control_norm_expr = ifelse(cell_line %in% names(wt_expression_line_coefficients), 
                                               control_lm$coefficients[1] + wt_expression_line_coefficients[cell_line],
                                               control_lm$coefficients[1]),
                    downstream_gene_name = unlist(lapply(strsplit(downstream_gene, ":"), "[[", 2))
      )
    names(df4lmm) <- c("target", "id", "cell_line", "donor", 'guide', "lfc", "control_norm_expr", "downstream_gene_name")
  } else {
    df4lmm <- dplyr::select(kd_expr, all_of(c("target", "id", "cell_line", "donor", downstream_gene))) %>%
      dplyr::mutate(control_norm_expr = ifelse(cell_line %in% names(wt_expression_line_coefficients), 
                                               control_lm$coefficients[1] + wt_expression_line_coefficients[cell_line],
                                               control_lm$coefficients[1]),
                    downstream_gene_name = unlist(lapply(strsplit(downstream_gene, ":"), "[[", 2))
      )
    names(df4lmm) <- c("target", "id", "cell_line", "donor", "lfc", "control_norm_expr", "downstream_gene_name")
    
  }
  df4lmm <- df4lmm %>% mutate(post_kd_expr = lfc + control_norm_expr)
  
  target_ind <- grep(colnames(kd_expr), pattern = paste0(":", target_gene, ":"))
  is_target_expressed <- (length(target_ind == 1) & include_line_quality == T)
  
  if (is_target_expressed){
    target_colname <- colnames(kd_expr)[target_ind]
    target_control_lm <- readRDS(paste0(OutFolder, "/6a_run_control_lm/", paste0(date, "/gene-", gsub(target_colname, pattern = ":", replacement = "-"), ".RDS")))
    target_control_lm_coefficients <- target_control_lm$coefficients[grep(names(target_control_lm$coefficients), pattern = "cell_line")]
    names(target_control_lm_coefficients) <- gsub(names(target_control_lm_coefficients), pattern= "cell_line", replacement = "")
    df4lmm <- df4lmm %>%
      mutate(on_target_lfc = kd_expr[, target_ind],
             on_target_expr = on_target_lfc + ifelse(cell_line %in% names(target_control_lm_coefficients), 
                                                     target_control_lm_coefficients[cell_line],
                                                     0))
  }
  
  if (include_sex == T){
    sexes <- line_metadata$sex; names(sexes) <- line_metadata$name
    df4lmm$sex <- sexes[match(df4lmm$cell_line, names(sexes))]
  }
  
  
  ## remove lines
  if (!is.null(lines2include)){
    df4lmm <- df4lmm %>% 
      dplyr::filter(cell_line %in% lines2include)
  }
  
  if (keep_singleton_lines == F){
    lines2keep <- data.frame(
      line = unique(df4lmm$cell_line),
      donor = unlist(lapply(strsplit(unique(df4lmm$cell_line), "_"), "[[", 1)),
      n_cells = as.numeric(table(df4lmm$cell_line))
    ) %>% dplyr::filter(n_cells > min_cells_per_gene_per_donor)
    donors2keep <- table(lines2keep$donor)
    donors2keep  <- names(donors2keep)[which(donors2keep  == 2)]
    lines2keep <- lines2keep %>% dplyr::filter(donor %in% donors2keep)
    #print(paste0("keeping ", paste(lines2keep$line, collapse = ', ')))
    df4lmm <- df4lmm %>% 
      dplyr::filter(cell_line %in% lines2keep$line)
  }
  
  return(df4lmm)
  
}

get_permutations <- function(target_gene, 
                             all_permutations = NULL,
                             perm_seed = 0, 
                             perm_start_ind = 1, num_perms = ifelse(perm_start_ind == 1, Inf, 1)){
  if (is.null(all_permutations)){
    target_line_mapping <- fread(file.path(OutFolder, "15a_get_line_perms", paste0(date, '_target_line_mapping.tsv')))
    target_line_mapping <- target_line_mapping %>% dplyr::filter(gene == target_gene)
    all_permutations <- readRDS(file.path(OutFolder, '15a_get_line_perms', paste0(date, "_line_set-", target_line_mapping$line_set_name, "_", target_line_mapping$n_paired_lines, "_perms_rnd-seed-", perm_seed, ".RDS")))
  }
  if (!(is.infinite(num_perms))){
    rtn <- all_permutations[perm_start_ind:(perm_start_ind + num_perms-1),]
  } else {
    rtn <- all_permutations[perm_start_ind:dim(all_permutations)[1],]
  }
  return(rtn)
}

plot_all <- function(
  target_gene = NULL, downstream_gene_name = NULL, 
  control_expression = NULL, knockdown_expression = NULL,
  lfc_df = NULL, 
  mean_only = F, lfc_df_is_mean = F,
  anno = c("H_control", "H_LFC", "H_expr_kd"),
                     n_col = 3, n_row = 1){
  
  if (is.null(lfc_df)){
    
    if (is.null(knockdown_expression)){
      knockdown_expression = get_knockdown_expression(target_gene)
    }
    if (is.null(control_expression)){
      control_expression = get_control_expression()
    }
    lfc_df <- get_df4lmm(kd_expr = knockdown_expression, downstream_gene_name = downstream_gene_name)
    
  } else {
    
    target_gene <- lfc_df$target[1]; downstream_gene_name <- lfc_df$downstream_gene_name[1]
    
  }
  
  if (lfc_df_is_mean == F){
    ## lfc
    control_df <- get_df4lmm(kd_expr = control_expression %>%
                               mutate(target = NonTargetGeneName), downstream_gene_name = downstream_gene_name)
    df4plot <- data.frame(
      cell_line = c(control_df$cell_line, rep(lfc_df$cell_line, 2)),
      donor = c(unlist(lapply(strsplit(control_df$cell_line, "_"), "[[", 1)), rep(unlist(lapply(strsplit(lfc_df$cell_line, "_"), "[[", 1)), 2)),
      status = c(rep("1_Control Expression", dim(control_df)[1]), 
                 rep("2_Transcriptional Change", dim(lfc_df)[1]),
                 rep("3_Knockdown Expression", dim(lfc_df)[1])),
      expr = c(
        control_df$post_kd_expr,
        lfc_df$lfc, 
        lfc_df$post_kd_expr
      ))
    df4plot$status <- factor(df4plot$status)
    levels(df4plot$status) <- c("Control Expression", "Transcriptional Change", "Knockdown Expression")
    
  } else {
    #print('checker2')
    df4plot <- lfc_df %>% 
      mutate(
        control_expr = control_line_coef + control_norm_expr,
        post_kd_expr = control_line_coef + lfc + control_norm_expr,
             donor = unlist(lapply(strsplit(cell_line, "_"), "[[", 1))) %>%
      dplyr::select(c("downstream_gene_name", 'cell_line', 'donor', 'control_expr', 'lfc', 'post_kd_expr')) %>%
      reshape2::melt(id = c('downstream_gene_name', 'cell_line', 'donor'))
    df4plot$status <- factor(df4plot$variable)
    levels(df4plot$status) <- c("Control Expression", "Transcriptional Change", "Knockdown Expression")
    df4plot$mean_expr <- df4plot$value
   # print('checker3')
    
  }
  
  anno_df <- data.frame(status = factor(levels(df4plot$status)),
                        anno = anno,
                        donor = '')
  
  
  if (mean_only == T){
    
    p_bar <- ggplot(df4plot, aes(x = cell_line, y = mean_expr, fill = donor)) + 
      facet_wrap(~status, ncol = n_col, nrow = n_row) + 
      xlab("") + ylab("")+ 
      ggtitle(paste0(downstream_gene_name, " in ", target_gene, " Knockdowns")) + 
      geom_bar(stat = 'identity') + 
      theme_bw() + theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1), legend.position = 'none')
    p_bar <- p_bar + 
      geom_text(data = anno_df,
                hjust = 2, vjust = 2,
                mapping = aes(x = Inf, y = Inf, label = anno, fill = 'black')
      )
    
  } else {
    
    
    p_bar <- ggplot(df4plot, aes(x = cell_line, y = expr, col = donor)) + 
      facet_wrap(~status, ncol = n_col, nrow = n_row) + 
      xlab("") + ylab("")+ 
      ggtitle(paste0(downstream_gene_name, " in ", target_gene, " Knockdowns")) + 
      geom_jitter(size = 0.4, alpha = 0.4) + stat_summary(fun= mean, fun.min=mean, fun.max=mean, geom="crossbar", width=0.75, lwd = 0.4) + 
      theme_bw() + theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1), legend.position = 'none')
    p_bar <- p_bar + 
      geom_text(data = anno_df,
                hjust = 2, vjust = 2,
                mapping = aes(x = Inf, y = Inf, label = anno),
                col = 'black'
      )
    
  }
  
  #p_bar 
  return(p_bar)
  
}
plot_jitter <- function(df4lmm = NULL, 
                        target_gene = NULL, downstream_gene_name = NULL, 
                        control_expression = NULL, knockdown_expression = NULL,
                        sc_data = T, y_colname = 'lfc', mean_only = F, title = "",
                        anno = ''){
  
  if (is.null(df4lmm)){
    
    if (is.null(knockdown_expression)){
      knockdown_expression = get_knockdown_expression(target_gene)
    }
    if (is.null(control_expression)){
      control_expression = get_control_expression()
    }
    df4lmm <- get_df4lmm(kd_expr = knockdown_expression, downstream_gene_name = downstream_gene_name, include_guide = F)
    
  } else {
    
    target_gene <- df4lmm$target[1]; downstream_gene_name <- df4lmm$downstream_gene_name[1]
    
  }
  
  df4plot <- df4lmm
  df4plot$expr <- eval(parse(text = paste0('df4lmm$', y_colname)))
  
  if (mean_only==T){
    if (sc_data == T){
      df4plot <- df4plot %>%
        group_by(cell_line) %>%
        summarize(donor = unique(donor),
                  mean_expr = mean(expr)) %>%
        ungroup() %>%
        as.data.frame()
    }
    p_bar <- ggplot(df4plot, aes(x = cell_line, y = mean_expr, fill = donor)) + 
      xlab("") + ylab("")+ 
      ggtitle(title) + 
      geom_bar(stat = 'identity') + 
      annotate(geom = 'text', x = Inf, y = Inf, label = anno, hjust = 1.5, vjust = 3) + 
      theme_bw() + theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1), legend.position = 'none')
  } else {
    
    p_bar <- ggplot(df4plot, aes(x = cell_line, y = expr, col = donor)) + 
      xlab("") + ylab("")+ 
      ggtitle(title) + 
      geom_jitter(size = 0.4, alpha = 0.4) + stat_summary(fun= mean, fun.min=mean, fun.max=mean, geom="crossbar", width=0.75, lwd = 0.4) + 
      annotate(geom = 'text', x = Inf, y = Inf, label = anno, hjust = 1.5, vjust = 3) + 
      theme_bw() + 
      theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1), legend.position = 'none')
    
  }
  return(p_bar)
}

plot_scatter <- function(
  target_gene = NULL, downstream_gene_name = NULL, 
  control_expression = NULL, knockdown_expression = NULL,
  lfc_df = NULL, lfc_is_sc = T, color_by_sex = F,
  keep_singleton_lines = F,
  anno = ""){
  ## lfc_df just needs four columns: cell_line, donor, control_norm_expr and post_kd_expr
  if (is.null(lfc_df)){
    
    if (is.null(knockdown_expression)){
      knockdown_expression = get_knockdown_expression(target_gene)
    }
    if (is.null(control_expression)){
      control_expression = get_control_expression()
    }
    lfc_df <- get_df4lmm(kd_expr = knockdown_expression, downstream_gene_name = downstream_gene_name)
    
  } else {
    
    target_gene <- lfc_df$target[1]; downstream_gene_name <- lfc_df$downstream_gene_name[1]
    
  }
  
  
  if (lfc_is_sc){
    df4plot <- lfc_df %>%
      group_by(cell_line) %>%
      summarize(
        donor = unique(donor),
        n_cells = n(),
        control_norm_expr = unique(control_norm_expr),
        post_kd_expr = mean(post_kd_expr)
      )
  } else {
    df4plot <- lfc_df
  }
  
  if (keep_singleton_lines == F){
    n_lines <- table(df4plot$donor)
    df4plot <- dplyr::filter(df4plot, donor %in% names(n_lines[which(n_lines > 1)]))
  }
  
  if (color_by_sex == T){
    df4plot$donor <- LineMetadata$sex[match(df4plot$cell_line, LineMetadata$name)]
  }
  
  window_min <- min(c(0, df4plot$control_norm_expr, df4plot$post_kd_expr))
  window_max <- max(c(0, df4plot$control_norm_expr, df4plot$post_kd_expr))
  rtn <- list()
  rtn$df4plot <- df4plot
  p <- ggplot(df4plot, aes(x = control_norm_expr, y = post_kd_expr, col = donor, label = cell_line)) + 
    ggrepel::geom_text_repel() + 
    xlim(c(window_min, window_max)) + ylim(c(window_min, window_max)) + 
    xlab("Expression in Control Cells") + ylab("Expression in Knockdown Cells") + 
    ggtitle(paste0(downstream_gene_name, " Expression in ", target_gene, " Knockdowns")) + 
    geom_point() + 
    geom_abline(slope = 1, lty = 3, col = 'gray') + 
    annotate("text", label = anno, x = -Inf, y = Inf, hjust = -0.5, vjust = 3) + 
    theme_bw() + theme(legend.position = 'none')
  if (color_by_sex == T){
    p <- p + scale_color_manual('', values = c("Female" = female_pink, "Male" = male_blue))
  }
  #p
  rtn$p <- p
  return(p)
  
}

plot_permutation <- function(df4lmm = NULL,
                             perm_ind = NULL, 
                             all_permutations = NULL, line_perm = NULL,
                             target_gene = NULL, kd_expr = NULL, 
                             downstream_gene_name = NULL ,
                             anno = ''){
  
  ## load data
  if (is.null(df4lmm)){
    if (!(is.null(kd_expr))){
      df4lmm <- get_df4lmm(kd_expr = kd_expr,
                           downstream_gene_name = downstream_gene_name)
    } else {
      df4lmm <- get_df4lmm(target_gene = target_gene,
                           downstream_gene_name = downstream_gene_name)
    }
  }
  target_gene = df4lmm$target[1]; downstream_gene_name = df4lmm$downstream_gene_name[1]
  if (is.null(line_perm)){
    if (is.null(all_permutations)){
      line_perm = get_permutations(target_gene = target_gene, perm_start_ind = perm_ind, num_perms = 1)
    } else {
      line_perm = get_permutations(target_gene = target_gene, perm_start_ind = perm_ind, num_perms = 1, 
                                   all_permutations = all_permutations)
    }
    
  }
  
  line_permutation_mapping <- data.frame(
    name = names(line_perm),
    old_name = sort(unique(unique(df4lmm$cell_line))),
    new_name = line_perm
  )
  
  ## permuted lines
  df4lmm_permuted <- df4lmm
  df4lmm_permuted$cell_line <- line_permutation_mapping$name[match(df4lmm$cell_line, line_permutation_mapping$new_name)]
  df4lmm_permuted$old_cell_line <- line_permutation_mapping$name[match(df4lmm$cell_line, line_permutation_mapping$old_name)]
  df4lmm_permuted$donor <- gsub(df4lmm_permuted$cell_line, pattern = "_line.*", replacement = "")
  
  ## change the names in the original data frame
  df4lmm_unpermuted <- df4lmm
  df4lmm_unpermuted$cell_line <- line_permutation_mapping$name[match(df4lmm$cell_line, line_permutation_mapping$old_name)]
  df4lmm_unpermuted$donor <- gsub(df4lmm_unpermuted$cell_line, pattern = "_line.*", replacement = "")
  
  ## change colors
  df4lmm_permuted_colors <- df4lmm_unpermuted
  df4lmm_permuted_colors$donor <- df4lmm_permuted$donor
  
  
  df4plot <- as.data.frame(bind_rows(
    df4lmm_unpermuted %>%
      dplyr::select(c('cell_line', 'donor', 'lfc')) %>%
      mutate('status' = 'Non-permuted'),
    df4lmm_permuted_colors %>%
      dplyr::select(c('cell_line', 'donor', 'lfc')) %>%
      mutate('status' = 'Non-permuted, permuted colors'),
    df4lmm_permuted %>%
      dplyr::select(c('cell_line', 'donor', 'lfc')) %>%
      mutate('status' = 'Permuted')
  ))
  df4plot$status <- factor(df4plot$status)
  df4plot$cell_line <- gsub(gsub(gsub(df4plot$cell_line, pattern = "pair_", replacement = "Pair "),
                                 pattern = "_line_", replacement = ", Line "),
                            pattern = "_", replacement = " ")
  
  if (anno == ''){
    anno <- rep("", 3)
    dLL <- tryCatch(
      expr = formatC(logLik(lmer(as.formula(paste0('lfc ', var_expl_models['m2'])), df4lmm_unpermuted)) -
                     logLik(lmer(as.formula(paste0('lfc ', var_expl_models['m1'])), df4lmm_unpermuted)),
                     digits = 4),
    warning = function(x){
      rtn <- logLik(lmer(as.formula(paste0('lfc ', var_expl_models['m2'])), df4lmm_unpermuted)) - logLik(lmer(as.formula(paste0('lfc ', var_expl_models['m1'])), df4lmm_unpermuted))
      rtn <- paste0(formatC(rtn, digits = 4), " (warning)" )
      return(rtn)
    }, 
    error = function(e) {
      return(NULL)
    })
    if (!(is.null(dLL))){anno[1] <- paste0("dLL = ", dLL)}else {anno[1] <-  "Non-converging LMM"}
    
    
    dLL <- tryCatch(
      expr =  formatC(logLik(lmer(as.formula(paste0('lfc ', var_expl_models['m2'])), df4lmm_permuted)) - 
                      logLik(lmer(as.formula(paste0('lfc ', var_expl_models['m1'])), df4lmm_permuted)),
                      digits = 4),
      warning = function(x){
        rtn <- logLik(lmer(as.formula(paste0('lfc ', var_expl_models['m2'])), df4lmm_permuted)) - logLik(lmer(as.formula(paste0('lfc ', var_expl_models['m1'])), df4lmm_permuted))
        rtn <- paste0(formatC(rtn, digits = 4), " (warning)" )
        return(paste0(rtn))
      }, 
      error = function(e) {
        return(NULL)
      })
    if (!(is.null(dLL))){anno[3] <- paste0("dLL = ", dLL)} else {anno[3] <-  "Non-converging LMM"}
    
    anno_df <- data.frame(status = factor(levels(df4plot$status)),
                          anno = anno,
                          donor = '')
  }
  
  p_rtn <- ggplot(df4plot, aes(x = cell_line, y = lfc, col = donor)) + 
    facet_wrap(~ status, ncol = 1) + 
    xlab("") + ylab("")+ 
    ggtitle(paste0(downstream_gene_name, " in ", target_gene, " Knockdowns, Permutation ", perm_ind)) + 
    geom_jitter(size = 0.4, alpha = 0.4) + stat_summary(fun= mean, fun.min=mean, fun.max=mean, geom="crossbar", width=0.75, lwd = 0.4) + 
    theme_bw() + theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1), legend.position = 'none')
  p_rtn <- p_rtn + 
    geom_text(data = anno_df,
              hjust = 2, vjust = 2,
              mapping = aes(x = Inf, y = Inf, label = anno),
              col = 'black'
    )
  #p_rtn 
  return(list(plot = p_rtn, line_permutation_mapping=line_permutation_mapping, df4lmm_permuted=df4lmm_permuted))
}

## ---- heritability LMM


### some functions
get_lm_fit <- function(f, df4lmm){
  use_lmm <- grepl(f, pattern = '[|]')
  if (use_lmm == T){
    fit <- suppressMessages(suppressWarnings(
      tryCatch(expr = lmer(as.formula(f), data = df4lmm), 
               warning = function(x){
                 return(NULL)
               }, 
               error = function(e) {
                 return(NULL)
               })
    ))
    
  } else {
    fit <- suppressMessages(suppressWarnings(
      tryCatch(expr = lm(as.formula(f), data = df4lmm), 
               warning = function(x){
                 return(NULL)
               }, 
               error = function(e) {
                 return(NULL)
               })
      
    ))
  }
  return(fit)
}
get_lr_tests <- function(fits){
  log_like <- lapply(fits, FUN = function(f){
    if (is.null(f)){
      return(-Inf)
    }
    rtn <- as.numeric(logLik(f))
    return(rtn)
  })
  names(log_like) <- names(fits)
  
  rtn <- c(unlist(log_like))
  return(rtn)
}
get_coefs <- function(fit, donor_list = NULL, 
                      fixed_effects = gsub(grep(unlist(strsplit(as.character(formula(fit))[3], "[+]")), pattern = '[|]|1', value = T, invert = T), pattern = " ", replacement = ''),
                      random_effects = gsub(grep(unlist(strsplit(as.character(formula(fit))[3], "[+]")), pattern = '[|]', value = T), pattern = " |.*[|]|)", replacement = '')){
  ## only do this for the final model
  rtn <- list()
  
  if (is.null(fit)){
    
    rtn$donor_coefs <- rep(-Inf, length(donor_list))
    names(rtn$donor_coefs) <- donor_list
    rtn$intercept <- -Inf
    
    rtn$var_expl <- rep(-Inf, length(random_effects) + 1)
    names(rtn$var_expl) <- paste0("varExpl_", c(random_effects, "Residual"))
    
    rtn$fixed_effect_coefs <- rtn$fixed_effect_tvals <- rep(-Inf, length(fixed_effects))
    names(rtn$fixed_effect_coefs) <- paste0('coef_', fixed_effects)
    names(rtn$fixed_effect_tvals) <- paste0('tval_', fixed_effects)
    
  } else {
    ## donor coefficients
    donor_coefs <- coefficients(fit)$donor[,1]; names(donor_coefs) <- row.names(coefficients(fit)$donor)
    rtn$donor_coefs <- donor_coefs
    rtn$intercept <- summary(fit)$coefficients["(Intercept)", 1]
    
    ## variance explained
    varExplained <- tryCatch(
      calcVarPart(fit, showWarnings = F),
      warning = function(x){
        return(rep(NULL, length(c(fixed_effects, random_effects))))
      }, 
      error = function(e) {
        return(rep(NULL, length(c(fixed_effects, random_effects))))
      }
    )
    rtn$var_expl <- varExplained
    names(rtn$var_expl) <- paste0('varExpl_', c(sort(random_effects), sort(fixed_effects), 'Residual'))
    
    
    ## fixed effects
    if (length(fixed_effects) >= 1){
      rtn$fixed_effect_coefs <- summary(fit)$coefficients[-1, 1]
      names(rtn$fixed_effect_coefs) <- paste0('coef_', sort(fixed_effects))
      rtn$fixed_effect_tvals <- summary(fit)$coefficients[-1, 3]
      names(rtn$fixed_effect_tvals) <- paste0("tval_", sort(fixed_effects))
      
    }
    
  }
  
  return(rtn)
}



#got rid of the no wild-type
calc_fit_meta <- function(df4lmm, 
                          models_to_test,
                          compute_coefs = F, 
                          fixed_effects = fe,
                          random_effects = re,
                          include_variance_explained = F){
  
  rtn <- list()
  
  ### lfc
  ## lm fits
  fits <- lapply(models_to_test, get_lm_fit, df4lmm = df4lmm)
  names(fits) <- paste0("LL_", names(models_to_test))
  var_expl <- c(get_lr_tests(fits))
  
  ## var explained
  rtn$var_expl <- data.frame(
    target = df4lmm$target[1],
    downstream_gene_name = df4lmm$downstream_gene_name[1],
    t(var_expl)
  )
  
  
  if (compute_coefs == T){
    donor_coefs <- tryCatch(expr = get_coefs(fits[[length(fits)]], 
                                             donor_list = sort(unique(df4lmm$cell_line)), 
                                             fixed_effects = fixed_effects,
                                             random_effects = random_effects), 
                            warning = function(x){
                              return(NULL)
                            }, 
                            error = function(e) {
                              return(NULL)
                            })
    
    ## donor coefficients
    rtn$donor_coefs <- data.frame(
      target = df4lmm$target[1],
      downstream_gene_name = df4lmm$downstream_gene_name[1],
      donor = lines2keep$line,
      coef = ifelse(is.null(donor_coefs$donor_coefs), -Inf, donor_coefs$donor_coefs),
      intercept = ifelse(is.null(donor_coefs$intercept), -Inf, donor_coefs$intercept)
    )
    
    ## var explained
    if (!is.null(donor_coefs)){
      for (v in names(donor_coefs$fixed_effect_coefs)){
        eval(parse(text = paste0(
          "rtn$var_expl$", v, " <- donor_coefs$fixed_effect_coefs['", v, "']"
        )))
      }
      for (v in names(donor_coefs$fixed_effect_tvals)){
        eval(parse(text = paste0(
          "rtn$var_expl$", v, " <- donor_coefs$fixed_effect_tvals['", v, "']"
        )))
      }
      
      if (include_variance_explained == T){
        for (v in names(donor_coefs$var_expl)){
          eval(parse(text = paste0(
            "rtn$var_expl$", v, " <- donor_coefs$var_expl[['", v, "']]"
          )))
        }
      }
      
    } else {
      for (v in paste0('coef_', sort(fixed_effects))){
        eval(parse(text = paste0(
          "rtn$var_expl$", v, " <- -Inf"
        )))
      }
      for (v in paste0('tval_', sort(fixed_effects))){
        eval(parse(text = paste0(
          "rtn$var_expl$", v, " <- -Inf"
        )))
      }
      
      if (include_variance_explained == T){
        for (v in c(sort(random_effects), sort(fixed_effects), "Residual")){
          eval(parse(text = paste0(
            "rtn$var_expl$varExpl_", v, " <- -Inf"
          )))
        }
      }
      
    }
    
    
    
    
  }
  
  
  return(rtn)
}


run_perm <- function(df4lmm, 
                     val2calc = 'lfc',
                     tg = df4lmm$target[1], dg = df4lmm$downstream_gene_name[1],
                     take_log = F,
                     h = NULL, LL_line = NULL,
                     models_to_test = var_expl_models,
                     num_perms_to_beat = 10, max_convergent_perms = 10^4, max_num_perms_to_compute = 2*10^4, ## max number is the number of converged permutations
                     start_perm_ind = 1,
                     all_permutations2test = all_permutations[start_perm_ind:min(start_perm_ind + max_num_perms_to_compute - 1, dim(all_permutations)[1]),], 
                     make_negatives_zero = T){
  
  ## calculate the base value
  if (is.null(LL_line)){
    ms <- paste0(val2calc, models_to_test[c('m1')]); names(ms) <- names(models_to_test[c('m1')])
    m1_res <- suppressMessages(suppressWarnings(
      calc_fit_meta(df4lmm = df4lmm, 
                    models_to_test = ms)
    ))
    LL_line <- m1_res$var_expl$LL_m1
  }
  
  if (is.infinite(LL_line)){
    df2write <- data.frame(
      target = tg,
      downstream_gene_name = dg,
      perm_ind = 0,
      LL_m2 = -Inf,
      lfc_dLL_donor = -Inf
    )
    return(df2write)
  }
  
  #true value
  if (is.null(h)){
    ms <- paste0(val2calc, models_to_test[c('m2')]); names(ms) <- names(models_to_test[c('m2')])
    m2_res <- suppressMessages(suppressWarnings(
      calc_fit_meta(df4lmm = df4lmm, 
                    models_to_test = ms)
    ))
    h <- m2_res$var_expl$LL_m2 - LL_line
  }
  if (make_negatives_zero){if (h < 0){h <- 0}}
  if (take_log == T){h <- log(h)}
  
  num_perms_with_higher_dLL <- num_perms_computed <- num_converged_perms <- 0
  ms <- paste0(val2calc, models_to_test); names(ms) <- names(models_to_test)
  df2write <- rep(0, max_num_perms_to_compute)
  if (class(all_permutations2test)[1] == "character"){
    total_perms2test <-1
  } else {
    total_perms2test <-dim(all_permutations2test)[1]
  }
   
  while ( (num_perms_with_higher_dLL < num_perms_to_beat) & 
          (num_converged_perms < max_convergent_perms) & 
          (num_perms_computed < total_perms2test)){
    
    #print(paste0("# of permutations computed:", num_perms_computed))
    if (class(all_permutations2test)[1] == "character"){
      line_perm <- all_permutations2test
    } else {
      line_perm <- all_permutations2test[num_perms_computed + 1,]
    }
    df4lmm_permuted <- df4lmm
    new_line <- names(line_perm)[match(df4lmm_permuted$cell_line, line_perm)]
    new_donor <- gsub(new_line, pattern = "_line.*", replacement = "")
    df4lmm_permuted$cell_line <- new_line
    df4lmm_permuted$donor <- new_donor
    res <- suppressMessages(suppressWarnings(
      calc_fit_meta(df4lmm = df4lmm_permuted, 
                    models_to_test = ms)
    ))
    
    num_perms_computed<- num_perms_computed + 1
    df2write[num_perms_computed] <- res$var_expl$LL_m2
    h_permuted <- res$var_expl$LL_m2 - LL_line
    #print(paste0("h_permuted:", h_permuted))
    if (!is.infinite(h_permuted)){ num_converged_perms <- num_converged_perms + 1 } #else {print('permutation didnt converge')}
    if (make_negatives_zero == T){if (h_permuted < 0){h_permuted <- 0}}
    if (take_log == T){h_permuted <- log(h_permuted)}
    if (h_permuted >= h & !(is.infinite(res$var_expl$LL_m2))){
      #print(num_perms_computed)
      #print(paste0("h: ", h))
      num_perms_with_higher_dLL <- num_perms_with_higher_dLL + 1
    }
    
  }
  df2write <- df2write[1:num_perms_computed]
  df2write <- data.frame(
    target = tg,
    downstream_gene_name = dg,
    perm_ind = (start_perm_ind):(start_perm_ind + num_perms_computed - 1),
    LL_m2 = df2write
  ) 
  if (take_log == T){
    df2write$lfc_dLL_donor <- log(df2write$LL_m2 - LL_line)
  } else {
    df2write$lfc_dLL_donor <- df2write$LL_m2 - LL_line
  }
  return(df2write)
}
 

## The plotting function
eqarrowPlot <- function(graph, layout, edge.lty=rep(1, ecount(graph)),
                        edge.arrow.size=rep(1, ecount(graph)),
                        vertex.shape="circle",
                        vertex.size = rep(10, ecount(graph) ),
                        vertex.color = rep('gray',ecount(graph) ), 
                        edge.color = rep('gray',ecount(graph) ),
                        edge.width = rep(1,ecount(graph) ),
                        edge.curved=autocurve.edges(graph), asp = 1, ...) {
  plot(graph, edge.lty=0, edge.arrow.size=0, layout=layout,
       vertex.size = vertex.size,
       vertex.shape="none", asp = asp)
  for (e in seq_len(ecount(graph))) {
    graph2 <- delete.edges(graph, E(graph)[(1:ecount(graph))[-e]])
    plot(graph2, edge.lty=edge.lty[e], edge.arrow.size=edge.arrow.size[e],
         edge.curved=edge.curved[e], layout=layout, vertex.shape="none",
         edge.color = edge.color[e],
         vertex.size = vertex.size[e],
         vertex.label=NA, add=TRUE, edge.width = edge.width[e])
  }
  plot(graph, edge.lty=0, edge.arrow.size=0, layout=layout,
       vertex.size = vertex.size,
       vertex.shape=vertex.shape, vertex.color = vertex.color, add=TRUE)
  invisible(NULL)
}

# Area under a stepwise curve
step_auc <- function(x, y){
  sum(diff(x) * y[-length(y)])
}

# Adjust for PR AUC
pr_auc <- function(recall, precision) {
  # Drop initial NA with thresh -inf
  na <- is.na(precision) | is.na(recall)
  precision <- precision[!na]
  recall <- recall[!na]
  # Add additional recall = 0 point
  step_auc(c(0, recall), c(precision[1], precision))
}

# Calculate ROC curve
calc_roc <- function(tbl, true_col, var_col, greater = TRUE, max_steps = 500, max_matrix_size = 100000){
  true_col <- enquo(true_col)
  var_col <- enquo(var_col)
  
  tbl <- select(tbl, !!true_col, !!var_col) %>%
    drop_na()
  if (nrow(tbl) == 0){
    return(tibble(TP=NA, TN=NA, FP=NA, FN=NA))
  }
  
  true <- pull(tbl, !!true_col)
  var <- pull(tbl, !!var_col)
  
  unique_values <- unique(var)
  if (length(unique_values) > max_steps) {
    steps <- c(-Inf, seq(from = min(unique_values), to = max(unique_values), length.out = max_steps), Inf)
  } else {
    steps <- c(-Inf, sort(unique_values), Inf)
  }
  print('length true')
  print(length(true))
  print('# of steps')
  print(length(steps))
  print('product')
  print(as.numeric(length(true))*as.numeric(length(steps)))
  if (as.numeric(length(true))*as.numeric(length(steps)) < max_matrix_size) {
    tbl <- calc_roc_matrix(true, var, steps, greater = greater)
  } else {
    tbl <- calc_roc_loop(true, var, steps, greater = greater)
  }
  
  if (greater){
    tbl <- arrange(tbl, desc(thresh))
  } else {
    tbl <- arrange(tbl, thresh)
  }
  
  tbl$auc <- step_auc(tbl$fpr, tbl$tpr)
  return(tbl)
}

calc_roc_matrix <- function(true, var, steps, greater = TRUE) {
  true_mat <- matrix(true, nrow = length(true), ncol = length(steps))
  var_mat <- matrix(var, nrow = length(var), ncol = length(steps))
  thresh_mat <- matrix(steps, nrow = length(var), ncol = length(steps), byrow = TRUE)
  
  if (greater){
    preds <- var_mat >= thresh_mat
  } else {
    preds <- var_mat <= thresh_mat
  }
  
  tp <- colSums(preds & true_mat)
  tn <- colSums(!preds & !true_mat)
  fp <- colSums(preds & !true_mat)
  fn <- colSums(!preds & true_mat)
  tbl <- tibble(thresh = steps, tp = tp, tn = tn, fp = fp, fn = fn,
                tpr = tp / (tp + fn),
                tnr = tn / (tn + fp),
                fpr = fp / (tn + fp),
                precision = tp / (tp + fp))
  return(tbl)
}

calc_roc_loop <- function(true, var, steps, greater = TRUE) {
  if (greater){
    tp <- map_int(steps, ~sum((var >= .) & true))
    tn <- map_int(steps, ~sum(!(var >= .) & !true))
    fp <- map_int(steps, ~sum((var >= .) & !true))
    fn <- map_int(steps, ~sum(!(var >= .) & true))
  } else {
    tp <- map_int(steps, ~sum((var <= .) & true))
    tn <- map_int(steps, ~sum(!(var <= .) & !true))
    fp <- map_int(steps, ~sum((var <= .) & !true))
    fn <- map_int(steps, ~sum(!(var <= .) & true))
  }
  
  tbl <- tibble(thresh = steps, tp = tp, tn = tn, fp = fp, fn = fn,
                tpr = tp / (tp + fn),
                tnr = tn / (tn + fp),
                fpr = fp / (tn + fp),
                precision = tp / (tp + fp))
  return(tbl)
}


auc_labeled_model <- function(model, auc){
  out <- str_c(model, " (AUC = ", signif(auc, 2), ")")
  
  ord <- order(auc, decreasing = TRUE)
  levs <- unique(out[ord])
  
  return(factor(out, levels = levs))
}
